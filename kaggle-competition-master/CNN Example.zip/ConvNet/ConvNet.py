from keras.callbacks import ReduceLROnPlateau
from keras.layers import Conv2D, Dense, Dropout, Flatten, MaxPooling2D
from keras.layers.normalization import BatchNormalization
from keras.models import Sequential
from keras.preprocessing.image import ImageDataGenerator
from keras.utils import to_categorical
from sklearn.model_selection import train_test_split
import keras
import numpy as np

indexForLabelName = {'empty'       : 0x00, 'sink'       : 0x01, 'pear'      : 0x02, 'moustache' : 0x03,
                     'nose'        : 0x04, 'skateboard' : 0x05, 'penguin'   : 0x06, 'peanut'    : 0x07,
                     'skull'       : 0x08, 'panda'      : 0x09, 'paintbrush': 0x0A, 'nail'      : 0x0B,
                     'apple'       : 0x0C, 'rifle'      : 0x0D, 'mug'       : 0x0E, 'sailboat'  : 0x0F,
                     'pineapple'   : 0x10, 'spoon'      : 0x11, 'rabbit'    : 0x12, 'shovel'    : 0x13,
                     'rollerskates': 0x14, 'screwdriver': 0x15, 'scorpion'  : 0x16, 'rhinoceros': 0x17,
                     'pool'        : 0x18, 'octagon'    : 0x19, 'pillow'    : 0x1A, 'parrot'    : 0x1B,
                     'squiggle'    : 0x1C, 'mouth'      : 0x1D, 'pencil'    : 0x1E}

labelNameForIndex = ['empty'       , 'sink'       , 'pear'      , 'moustache' ,
                     'nose'        , 'skateboard' , 'penguin'   , 'peanut'    ,
                     'skull'       , 'panda'      , 'paintbrush', 'nail'      ,
                     'apple'       , 'rifle'      , 'mug'       , 'sailboat'  ,
                     'pineapple'   , 'spoon'      , 'rabbit'    , 'shovel'    ,
                     'rollerskates', 'screwdriver', 'scorpion'  , 'rhinoceros',
                     'pool'        , 'octagon'    , 'pillow'    , 'parrot'    ,
                     'squiggle'    , 'mouth'      , 'pencil']

def generateLabels(labels):

    index = 0
    labelsString = ""
    labelsString += 'Id,Category\n'

    for label in labels:

        column = 0
        for i in range(len(label)): column = i if label[i] > label[column] else column
        labelsString += str(index) + ',' + labelNameForIndex[column] + '\n'
        index += 1

    return labelsString

def generateNetworkModel():

    networkModel = Sequential()
    networkModel.add(Conv2D(64, 3, activation = 'relu', kernel_initializer = 'he_normal', input_shape = (28, 28, 1)))
    networkModel.add(Conv2D(64, 3, activation = 'relu', kernel_initializer = 'he_normal'))
    networkModel.add(MaxPooling2D(pool_size = 2))
    networkModel.add(Dropout(0.4))
    networkModel.add(Conv2D(128, 3, activation = 'relu', padding = 'same', kernel_initializer = 'he_normal'))
    networkModel.add(Conv2D(128, 3, activation = 'relu', padding = 'same', kernel_initializer = 'he_normal'))
    networkModel.add(MaxPooling2D(pool_size = 2))
    networkModel.add(Dropout(0.5))
    networkModel.add(Conv2D(256, 3, activation = 'relu', padding = 'same', kernel_initializer = 'he_normal'))
    networkModel.add(Dropout(0.5))
    networkModel.add(Flatten())
    networkModel.add(Dense(256, activation = 'relu'))
    networkModel.add(BatchNormalization())
    networkModel.add(Dropout(0.5))
    networkModel.add(Dense(0x1F, activation = 'softmax'))
    networkModel.compile(loss = keras.losses.categorical_crossentropy,
                         optimizer = keras.optimizers.RMSprop(),
                         metrics = ['accuracy'])
    return networkModel
    
def loadFeatures(filePath): return np.load(filePath).reshape(10000, 28, 28, 1).clip(min = 0x00, max = 0xFF).astype('float32') / 0xFF

def loadLabels(filePath):

    with open(filePath) as data:

        _ = data.readline()
        labels = []
        for line in data: labels.append(indexForLabelName[line.strip().split(',')[1]])
        return to_categorical(labels, 0x1F)

def shouldStop(accuracy, loss, validationAccuracy, validationLoss):

    return accuracy > 0.84 and validationAccuracy > 0.78

#   loads features and labels into memory

trainingFeatures = loadFeatures('train_images_reduced.npy')
trainingLabels = loadLabels('train_labels.csv')

#   splits data into separate training and testing set

trainingFeatures, testingFeatures, trainingLabels, testingLabels = train_test_split(trainingFeatures,
                                                                                    trainingLabels,
                                                                                    random_state = 42,
                                                                                    test_size = 0.1)

#   defines random transform applied on images

transform = ImageDataGenerator(rotation_range=15, zoom_range = 0.1,
                               width_shift_range=0.1, height_shift_range=0.1,
                               horizontal_flip=True, shear_range = 0.1)
transform.fit(trainingFeatures)

#   generates a wide model for training purposes

model = generateNetworkModel()
model.summary()

#   trains model on randomly transformed image data iteratively

learningRateMonitor = ReduceLROnPlateau(monitor = 'val_acc', patience = 3,
                                        verbose = 1, factor = 0.5, min_lr = 0.0001)

while True:

    metrics = model.fit_generator(transform.flow(trainingFeatures, trainingLabels, batch_size = 64),
                                epochs = 1, validation_data = (testingFeatures, testingLabels),
                                steps_per_epoch = trainingFeatures.shape[0] // 64,
                                callbacks = [learningRateMonitor])
    print('_________________________________________________________________')
    if shouldStop(metrics.history['acc'][0], metrics.history['loss'][0],
                  metrics.history['val_acc'][0], metrics.history['val_loss'][0]): break

#   saves learned model to directory and outputs general metrics on training set

model.save('model.h5')
trainingFeatures = loadFeatures('train_images_reduced.npy')
actualLabels = generateLabels(loadLabels('train_labels.csv')).split('\n', 1)[1].split('\n')
predictedLabels = generateLabels(model.predict(trainingFeatures)).split('\n', 1)[1].split('\n')
correctPredictions = 0
for i in range(10000): correctPredictions += 1 if actualLabels[i] == predictedLabels[i] else 0
print('Model Accuracy: ' + str(correctPredictions / 10000.0))
print('_________________________________________________________________')

#   computes individual class metrics

for labelIndex in range(0x1F):

    label = labelNameForIndex[labelIndex]
    metrics = [[0, 0], [0, 0]]

    for imageIndex in range(10000):
        
        actualLabel = actualLabels[imageIndex].split(',')[1]
        predictedLabel = predictedLabels[imageIndex].split(',')[1]
        metrics[1 if label == actualLabel else 0][1 if label == predictedLabel else 0] += 1

    falseNegative = metrics[1][0]
    falsePositive = metrics[0][1]
    trueNegative = metrics[0][0]
    truePositive = metrics[1][1]
    accuracy = (trueNegative + truePositive) / 10000
    precision = truePositive / (falsePositive + truePositive) if falsePositive + truePositive != 0 else None
    sensitivity = truePositive / (falseNegative + truePositive) if falseNegative + truePositive != 0 else None
    specificity = trueNegative / (falsePositive + trueNegative) if falsePositive + trueNegative != 0 else None
    score = 2 / ((1 / sensitivity) + (1 / precision)) if sensitivity != 0 and precision != 0 else None
    print('Metrics for \'' + label + '\' Label:')
    print('False Negative Count: ' + str(falseNegative))
    print('False Positive Count: ' + str(falsePositive))
    print('True Negative Count: ' + str(trueNegative))
    print('True Positive Count: ' + str(truePositive))
    print('Accuracy: ' + str(accuracy))
    print('Precision: ' + (str(precision) if precision != None else 'N/A'))
    print('Sensitivity: ' + (str(sensitivity) if sensitivity != None else 'N/A'))
    print('Specificity: ' + (str(specificity) if specificity != None else 'N/A'))
    print('F-Score: ' + (str(score) if score != None else 'N/A'))
    print('_________________________________________________________________')

#   performs predictions on test data

testingFeatures = loadFeatures('test_images_reduced.npy')
with open('test_labels.csv', 'w') as file: file.write(generateLabels(model.predict(testingFeatures)))
